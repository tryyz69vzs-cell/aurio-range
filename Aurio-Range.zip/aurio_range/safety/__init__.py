"""Safety gate package."""
