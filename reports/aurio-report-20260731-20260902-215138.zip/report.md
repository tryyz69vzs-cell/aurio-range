# Aurio Range Red Team 경기 보고서

## 경기 요약

| 항목 | 값 |
| --- | --- |
| 경기 시각 | `2026-09-02T21:51:38Z` |
| seed | `20260731` |
| 난이도 | `mixed` |
| 엄격도 | `balanced` |
| 사용자 프로필 | `average, careless, cautious` |
| Red 점수 | **9** |
| Blue 점수 | **26** |

## 원시 지표

| 지표 | 값 |
| --- | --- |
| false positive | 0 |
| friction | 3 |
| false negative | 0 |
| warning escape | 0 |
| harm click | 0 |
| harm submit | 0 |
| credential exposure | 0 |
| takeover success | 0 |
| exposure prevented by prior lock | 0 |
| containment success | 0 |
| user saved | 0 |
| defensive overreaction | 1 |
| 평균 탐지 단계 | 1.0 |
| 평균 봉쇄 단계 | 2.0 |
| 위조 시도 / 격리 / 경고 / 허용 | 9 / 6 / 3 / 0 |

## Red 시도 요약

| ID | 난이도 | 프로필 | 전술 계열 | 전략 | 위험 | 조치 | 클릭 | 제출 | 결과 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `A001` | easy | cautious | `incident_echo` | `static-event-shadowing` | 125 | 격리 | - | - | Red 실패 |
| `A002` | medium | cautious | `incident_echo` | `static-event-shadowing` | 70 | 격리 | - | - | Red 실패 |
| `A003` | hard | cautious | `incident_echo` | `static-event-shadowing` | 55 | 경고 | - | - | 부분 성공 |
| `A004` | easy | average | `incident_echo` | `static-event-shadowing` | 125 | 격리 | - | - | Red 실패 |
| `A005` | medium | average | `incident_echo` | `static-event-shadowing` | 70 | 격리 | - | - | Red 실패 |
| `A006` | hard | average | `incident_echo` | `static-event-shadowing` | 55 | 경고 | - | - | 부분 성공 |
| `A007` | easy | careless | `incident_echo` | `static-event-shadowing` | 125 | 격리 | - | - | Red 실패 |
| `A008` | medium | careless | `incident_echo` | `static-event-shadowing` | 70 | 격리 | - | - | Red 실패 |
| `A009` | hard | careless | `incident_echo` | `static-event-shadowing` | 55 | 경고 | - | - | 부분 성공 |

## Red 시도별 상세 분석

### A001 · 사건 그림자 (Red 실패)

- 난이도 / 엄격도: `easy` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `cautious`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_only_no_official_counterpart_reference`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_basic` / `single_column_compact`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 125 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 미등록 합성 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `sender_registry` = `unregistered` (+25)
  - `display_alignment` = `misaligned` (+20)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `ingress_channel, sender_auth, state_consistency`
- 탐지 지연: 1단계

총점 125점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), sender_registry(unregistered, +25) 입니다. 점수를 올리지 못한 신호는 ingress_channel, sender_auth, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

cautious 프로필은 검증 시도율이 가장 높고 경고 순응률도 가장 높은 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A001.png`, `artifacts/forged-page-A001.png`, `artifacts/official-preview-A001.png`

---

### A002 · 사건 그림자 (Red 실패)

- 난이도 / 엄격도: `medium` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `cautious`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_arrives_alongside_unrelated_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_polished` / `single_column_hero`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 70 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `signature_validity` = `NONE` (+15)
- 구분력 없던 신호: `display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority`
- 탐지 지연: 1단계

총점 70점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), signature_validity(NONE, +15) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

cautious 프로필은 검증 시도율이 가장 높고 경고 순응률도 가장 높은 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A002.png`, `artifacts/forged-page-A002.png`, `artifacts/official-preview-A002.png`

---

### A003 · 사건 그림자 (부분 성공)

- 난이도 / 엄격도: `hard` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `cautious`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `immediately_after_platform_incident`
- 공식 사건과의 관계: `references_the_same_real_incident`
- 알림 짝짓기: `forged_shadows_the_triggered_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_incident_echo` / `single_column_hero_evidence`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 55 → 밴드 `MEDIUM` → 사전 조치 **경고**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `aligned_with_real_incident` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency`
- 탐지 지연: 1단계

총점 55점으로 balanced 임계값(경고 30점, 격리 70점) 기준 MEDIUM 밴드가 되어 사전 조치 warn 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), signature_validity(NONE, +15), urgency_authority(present, +10) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `WARN_ACKNOWLEDGED → USER_VERIFY → USER_ABORT`
- 검증 True / 신고 False / 클릭 False / 제출 False
- 경고 표시 True / 경고 이탈 False

cautious 프로필은 검증 시도율이 가장 높고 경고 순응률도 가장 높은 유형입니다. Blue의 경고 배너를 수용하고 진행을 멈췄습니다. 공식 앱에서 사건 기록을 확인했고 기록이 실제로 존재해 메시지의 주장이 사실처럼 보였습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **부분 성공**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 방어는 통과했지만 합성 사용자의 행동을 전혀 유도하지 못했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

이 전술의 결과를 다른 프로필과 엄격도 조합에서 반복 실행해 단일 경기 결과가 아닌 누적 경향으로 확인할 것.

미리보기: `artifacts/forged-preview-A003.png`, `artifacts/forged-page-A003.png`, `artifacts/official-preview-A003.png`

---

### A004 · 사건 그림자 (Red 실패)

- 난이도 / 엄격도: `easy` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `average`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_only_no_official_counterpart_reference`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_basic` / `single_column_compact`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 125 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 미등록 합성 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `sender_registry` = `unregistered` (+25)
  - `display_alignment` = `misaligned` (+20)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `ingress_channel, sender_auth, state_consistency`
- 탐지 지연: 1단계

총점 125점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), sender_registry(unregistered, +25) 입니다. 점수를 올리지 못한 신호는 ingress_channel, sender_auth, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

average 프로필은 상황에 따라 검증과 클릭이 갈리는 중간 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A004.png`, `artifacts/forged-page-A004.png`, `artifacts/official-preview-A004.png`

---

### A005 · 사건 그림자 (Red 실패)

- 난이도 / 엄격도: `medium` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `average`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_arrives_alongside_unrelated_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_polished` / `single_column_hero`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 70 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `signature_validity` = `NONE` (+15)
- 구분력 없던 신호: `display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority`
- 탐지 지연: 1단계

총점 70점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), signature_validity(NONE, +15) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

average 프로필은 상황에 따라 검증과 클릭이 갈리는 중간 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A005.png`, `artifacts/forged-page-A005.png`, `artifacts/official-preview-A005.png`

---

### A006 · 사건 그림자 (부분 성공)

- 난이도 / 엄격도: `hard` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `average`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `immediately_after_platform_incident`
- 공식 사건과의 관계: `references_the_same_real_incident`
- 알림 짝짓기: `forged_shadows_the_triggered_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_incident_echo` / `single_column_hero_evidence`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 55 → 밴드 `MEDIUM` → 사전 조치 **경고**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `aligned_with_real_incident` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency`
- 탐지 지연: 1단계

총점 55점으로 balanced 임계값(경고 30점, 격리 70점) 기준 MEDIUM 밴드가 되어 사전 조치 warn 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), signature_validity(NONE, +15), urgency_authority(present, +10) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `WARN_IGNORED → USER_VERIFY → USER_IGNORE`
- 검증 True / 신고 False / 클릭 False / 제출 False
- 경고 표시 True / 경고 이탈 False

average 프로필은 상황에 따라 검증과 클릭이 갈리는 중간 유형입니다. Blue의 경고 배너가 붙었지만 이를 무시하고 진행했습니다. 공식 앱에서 사건 기록을 확인했고 기록이 실제로 존재해 메시지의 주장이 사실처럼 보였습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **부분 성공**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 방어는 통과했지만 합성 사용자의 행동을 전혀 유도하지 못했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

이 전술의 결과를 다른 프로필과 엄격도 조합에서 반복 실행해 단일 경기 결과가 아닌 누적 경향으로 확인할 것.

미리보기: `artifacts/forged-preview-A006.png`, `artifacts/forged-page-A006.png`, `artifacts/official-preview-A006.png`

---

### A007 · 사건 그림자 (Red 실패)

- 난이도 / 엄격도: `easy` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `careless`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_only_no_official_counterpart_reference`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_basic` / `single_column_compact`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 125 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 미등록 합성 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `sender_registry` = `unregistered` (+25)
  - `display_alignment` = `misaligned` (+20)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `ingress_channel, sender_auth, state_consistency`
- 탐지 지연: 1단계

총점 125점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), sender_registry(unregistered, +25) 입니다. 점수를 올리지 못한 신호는 ingress_channel, sender_auth, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

careless 프로필은 긴급 표현에 크게 반응하고 검증을 거의 하지 않는 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A007.png`, `artifacts/forged-page-A007.png`, `artifacts/official-preview-A007.png`

---

### A008 · 사건 그림자 (Red 실패)

- 난이도 / 엄격도: `medium` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `careless`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_arrives_alongside_unrelated_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_polished` / `single_column_hero`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 70 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `signature_validity` = `NONE` (+15)
- 구분력 없던 신호: `display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority`
- 탐지 지연: 1단계

총점 70점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), signature_validity(NONE, +15) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

careless 프로필은 긴급 표현에 크게 반응하고 검증을 거의 하지 않는 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A008.png`, `artifacts/forged-page-A008.png`, `artifacts/official-preview-A008.png`

---

### A009 · 사건 그림자 (부분 성공)

- 난이도 / 엄격도: `hard` / `balanced`
- 전략: `static-event-shadowing`
- 전술 계열: `incident_echo` / 전술 ID `event-shadowing`
- 대상 프로필: `careless`

**Red는 무엇을 시험했는가**

- 사용 목적: event_shadowing: 실제 합성 보안 사건 직후 같은 사건을 사칭해 사건 기록 신호를 무력화하는 실험
- 방어 가설: 사건 기록 신호가 무력화된 상태에서 발신 인증·서명·목적지 소유권만으로 방어가 성립하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `immediately_after_platform_incident`
- 공식 사건과의 관계: `references_the_same_real_incident`
- 알림 짝짓기: `forged_shadows_the_triggered_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_incident_echo` / `single_column_hero_evidence`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 55 → 밴드 `MEDIUM` → 사전 조치 **경고**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `aligned_with_real_incident` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency`
- 탐지 지연: 1단계

총점 55점으로 balanced 임계값(경고 30점, 격리 70점) 기준 MEDIUM 밴드가 되어 사전 조치 warn 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), signature_validity(NONE, +15), urgency_authority(present, +10) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `WARN_ACKNOWLEDGED → USER_NOT_VERIFIED → USER_ABORT`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 True / 경고 이탈 False

careless 프로필은 긴급 표현에 크게 반응하고 검증을 거의 하지 않는 유형입니다. Blue의 경고 배너를 수용하고 진행을 멈췄습니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **부분 성공**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 방어는 통과했지만 합성 사용자의 행동을 전혀 유도하지 못했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

이 전술의 결과를 다른 프로필과 엄격도 조합에서 반복 실행해 단일 경기 결과가 아닌 누적 경향으로 확인할 것.

미리보기: `artifacts/forged-preview-A009.png`, `artifacts/forged-page-A009.png`, `artifacts/official-preview-A009.png`

---

## 전략 진화 결과

- 세대 수 3 · 세대당 후보 8
- 최고 전략 `g0-seed-02-event_shadowin`
- 훈련 fitness 7.146 / 숨김 평가 fitness -4.515
- 훈련 시드 [105568, 105585] · 숨김 평가 시드 2개

| 세대 | 전략 | 부모 | 변경 필드 | 훈련 | 평가 | Δ | 판정 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | `g0-seed-02-event_shadowin` | `—` | `—` | 7.146 | -4.515 | -4.515 | keep |
| 30 | `g30-02-_follo` | `g29-11-_follo` | `header_variant` | 7.146 | -4.515 | -4.515 | keep |
| 0 | `g0-seed-05-recovery_follo` | `—` | `—` | 7.109 | -4.537 | -4.537 | keep |
| 0 | `g0-seed-07-policy_violati` | `—` | `—` | 6.884 | -4.665 | -4.665 | keep |
| 113 | `g113-02-_follo` | `g30-02-_follo` | `repetition_variant, notification_pairing` | 7.060 | -4.779 | -0.264 | drop |
| 113 | `g113-03-_follo` | `g30-02-_follo` | `signature_state` | 7.060 | -4.779 | -0.264 | drop |
| 113 | `g113-04-_follo` | `g0-seed-05-recovery_follo` | `mobile_layout, information_density` | 7.060 | -4.779 | -0.242 | drop |
| 113 | `g113-05-_follo` | `g0-seed-05-recovery_follo` | `CTA_variant` | 7.060 | -4.779 | -0.242 | drop |
| 114 | `g114-02-_follo` | `g113-03-_follo` | `reassurance_style` | 7.284 | -4.834 | -0.055 | drop |
| 114 | `g114-00-_follo` | `g113-02-_follo` | `followup_style` | 7.246 | -4.856 | -0.077 | drop |
| 114 | `g114-01-_follo` | `g113-02-_follo` | `signature_state, mobile_layout` | 7.246 | -4.856 | -0.077 | drop |

- **g0-seed-02-event_shadowin**: 패턴 `event_shadowing` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g30-02-_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g0-seed-05-recovery_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g0-seed-07-policy_violati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g113-02-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `repetition_variant, notification_pairing` 필드를 바꿨고, 숨김 평가에서 -4.52 → -4.78 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g113-03-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `signature_state` 필드를 바꿨고, 숨김 평가에서 -4.52 → -4.78 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g113-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout, information_density` 필드를 바꿨고, 숨김 평가에서 -4.54 → -4.78 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g113-05-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `CTA_variant` 필드를 바꿨고, 숨김 평가에서 -4.54 → -4.78 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g114-02-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `reassurance_style` 필드를 바꿨고, 숨김 평가에서 -4.78 → -4.83 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g114-00-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `followup_style` 필드를 바꿨고, 숨김 평가에서 -4.78 → -4.86 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g114-01-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `signature_state, mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.78 → -4.86 로 개선되지 못해 `drop` 판정을 받았습니다.

## Blue 방어 분석

| 신호 | 누적 점수 | 점수를 준 시도 수 |
| --- | --- | --- |
| `destination_ownership` | 270 | 9 |
| `official_event_record` | 150 | 6 |
| `signature_validity` | 135 | 9 |
| `sender_registry` | 75 | 3 |
| `display_alignment` | 60 | 3 |
| `urgency_authority` | 60 | 6 |
| `ingress_channel` | 0 | 0 |
| `sender_auth` | 0 | 0 |
| `state_consistency` | 0 | 0 |

탐지에 가장 크게 기여한 신호는 `destination_ownership` 로, 누적 270점을 기여했습니다.

## 사용자 행동 분석

| 프로필 | 시도 | 검증 | 신고 | 경고 | 경고 이탈 | 클릭 | 제출 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| average | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| careless | 3 | 0 | 0 | 1 | 0 | 0 | 0 |
| cautious | 3 | 1 | 0 | 1 | 0 | 0 | 0 |

## 연구 결론

1. 이번 경기의 종합 점수는 Red 9 대 Blue 26 으로 Blue 가 앞섰습니다. 위조 시도 9건 중 격리 6건, 경고 3건, 허용 0건입니다.
2. 이번 경기에서는 제출까지 도달한 전술이 없어, 방어가 모든 시도를 행동 이전 또는 행동 중간에 멈췄습니다.
3. 방어 비용 지표는 오격리 0건, 마찰 경고 3건, 미탐 0건입니다. 임계값을 조정할 때는 미탐 감소와 오격리 증가를 항상 함께 볼 것.
4. 다음 경기 제안: 같은 시드 20260731 를 유지한 채 탐지 엄격도만 바꿔 재실행하고, 미탐과 오격리가 교차하는 지점을 기록할 것.

## 안전 고지

- 이 보고서는 폐쇄형 합성 시뮬레이션의 결과만 담고 있습니다.
- 실제 서비스, 실제 계정, 실제 자격증명, 실제 외부 공격은 사용되지 않았습니다.
- 모든 사용자·계정·도메인은 합성이며 예약 도메인 안에서만 존재합니다.
- 메시지 원문, 활성 마크업, 목적지 주소, 서명 토큰, 계정 식별자, 데이터베이스 식별자는 의도적으로 제외되어 실제 발송에 재사용할 수 없습니다.
- 첨부된 미리보기 이미지는 정적 래스터이며 클릭·입력·제출·네트워크 요청 기능이 없습니다.
