# Aurio Range Red Team 경기 보고서

## 경기 요약

| 항목 | 값 |
| --- | --- |
| 경기 시각 | `2026-08-07T11:46:55Z` |
| seed | `20260731` |
| 난이도 | `mixed` |
| 엄격도 | `balanced` |
| 사용자 프로필 | `average, careless, cautious` |
| Red 점수 | **9** |
| Blue 점수 | **26** |

## 원시 지표

| 지표 | 값 |
| --- | --- |
| false positive | 0 |
| friction | 3 |
| false negative | 0 |
| warning escape | 0 |
| harm click | 0 |
| harm submit | 0 |
| credential exposure | 0 |
| takeover success | 0 |
| exposure prevented by prior lock | 0 |
| containment success | 0 |
| user saved | 0 |
| defensive overreaction | 1 |
| 평균 탐지 단계 | 1.0 |
| 평균 봉쇄 단계 | 2.0 |
| 위조 시도 / 격리 / 경고 / 허용 | 9 / 6 / 3 / 0 |

## Red 시도 요약

| ID | 난이도 | 프로필 | 전술 계열 | 전략 | 위험 | 조치 | 클릭 | 제출 | 결과 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `A001` | easy | cautious | `sender_forgery` | `static-obvious-spoof` | 125 | 격리 | - | - | Red 실패 |
| `A002` | medium | cautious | `sender_forgery` | `static-obvious-spoof` | 70 | 격리 | - | - | Red 실패 |
| `A003` | hard | cautious | `sender_forgery` | `static-obvious-spoof` | 55 | 경고 | - | - | 부분 성공 |
| `A004` | easy | average | `sender_forgery` | `static-obvious-spoof` | 125 | 격리 | - | - | Red 실패 |
| `A005` | medium | average | `sender_forgery` | `static-obvious-spoof` | 70 | 격리 | - | - | Red 실패 |
| `A006` | hard | average | `sender_forgery` | `static-obvious-spoof` | 55 | 경고 | - | - | 부분 성공 |
| `A007` | easy | careless | `sender_forgery` | `static-obvious-spoof` | 125 | 격리 | - | - | Red 실패 |
| `A008` | medium | careless | `sender_forgery` | `static-obvious-spoof` | 70 | 격리 | - | - | Red 실패 |
| `A009` | hard | careless | `sender_forgery` | `static-obvious-spoof` | 55 | 경고 | - | - | 부분 성공 |

## Red 시도별 상세 분석

### A001 · 명백한 발신 위조 (Red 실패)

- 난이도 / 엄격도: `easy` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `cautious`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_only_no_official_counterpart_reference`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_basic` / `single_column_compact`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 125 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 미등록 합성 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `sender_registry` = `unregistered` (+25)
  - `display_alignment` = `misaligned` (+20)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `ingress_channel, sender_auth, state_consistency`
- 탐지 지연: 1단계

총점 125점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), sender_registry(unregistered, +25) 입니다. 점수를 올리지 못한 신호는 ingress_channel, sender_auth, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

cautious 프로필은 검증 시도율이 가장 높고 경고 순응률도 가장 높은 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A001.png`, `artifacts/forged-page-A001.png`, `artifacts/official-preview-A001.png`

---

### A002 · 명백한 발신 위조 (Red 실패)

- 난이도 / 엄격도: `medium` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `cautious`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_arrives_alongside_unrelated_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_polished` / `single_column_hero`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 70 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `signature_validity` = `NONE` (+15)
- 구분력 없던 신호: `display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority`
- 탐지 지연: 1단계

총점 70점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), signature_validity(NONE, +15) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

cautious 프로필은 검증 시도율이 가장 높고 경고 순응률도 가장 높은 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A002.png`, `artifacts/forged-page-A002.png`, `artifacts/official-preview-A002.png`

---

### A003 · 명백한 발신 위조 (부분 성공)

- 난이도 / 엄격도: `hard` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `cautious`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `immediately_after_platform_incident`
- 공식 사건과의 관계: `references_the_same_real_incident`
- 알림 짝짓기: `forged_shadows_the_triggered_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_incident_echo` / `single_column_hero_evidence`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 55 → 밴드 `MEDIUM` → 사전 조치 **경고**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `aligned_with_real_incident` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency`
- 탐지 지연: 1단계

총점 55점으로 balanced 임계값(경고 30점, 격리 70점) 기준 MEDIUM 밴드가 되어 사전 조치 warn 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), signature_validity(NONE, +15), urgency_authority(present, +10) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `WARN_ACKNOWLEDGED → USER_VERIFY → USER_ABORT`
- 검증 True / 신고 False / 클릭 False / 제출 False
- 경고 표시 True / 경고 이탈 False

cautious 프로필은 검증 시도율이 가장 높고 경고 순응률도 가장 높은 유형입니다. Blue의 경고 배너를 수용하고 진행을 멈췄습니다. 공식 앱에서 사건 기록을 확인했고 기록이 실제로 존재해 메시지의 주장이 사실처럼 보였습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **부분 성공**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 방어는 통과했지만 합성 사용자의 행동을 전혀 유도하지 못했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

이 전술의 결과를 다른 프로필과 엄격도 조합에서 반복 실행해 단일 경기 결과가 아닌 누적 경향으로 확인할 것.

미리보기: `artifacts/forged-preview-A003.png`, `artifacts/forged-page-A003.png`, `artifacts/official-preview-A003.png`

---

### A004 · 명백한 발신 위조 (Red 실패)

- 난이도 / 엄격도: `easy` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `average`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_only_no_official_counterpart_reference`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_basic` / `single_column_compact`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 125 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 미등록 합성 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `sender_registry` = `unregistered` (+25)
  - `display_alignment` = `misaligned` (+20)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `ingress_channel, sender_auth, state_consistency`
- 탐지 지연: 1단계

총점 125점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), sender_registry(unregistered, +25) 입니다. 점수를 올리지 못한 신호는 ingress_channel, sender_auth, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

average 프로필은 상황에 따라 검증과 클릭이 갈리는 중간 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A004.png`, `artifacts/forged-page-A004.png`, `artifacts/official-preview-A004.png`

---

### A005 · 명백한 발신 위조 (Red 실패)

- 난이도 / 엄격도: `medium` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `average`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_arrives_alongside_unrelated_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_polished` / `single_column_hero`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 70 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `signature_validity` = `NONE` (+15)
- 구분력 없던 신호: `display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority`
- 탐지 지연: 1단계

총점 70점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), signature_validity(NONE, +15) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

average 프로필은 상황에 따라 검증과 클릭이 갈리는 중간 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A005.png`, `artifacts/forged-page-A005.png`, `artifacts/official-preview-A005.png`

---

### A006 · 명백한 발신 위조 (부분 성공)

- 난이도 / 엄격도: `hard` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `average`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `immediately_after_platform_incident`
- 공식 사건과의 관계: `references_the_same_real_incident`
- 알림 짝짓기: `forged_shadows_the_triggered_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_incident_echo` / `single_column_hero_evidence`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 55 → 밴드 `MEDIUM` → 사전 조치 **경고**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `aligned_with_real_incident` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency`
- 탐지 지연: 1단계

총점 55점으로 balanced 임계값(경고 30점, 격리 70점) 기준 MEDIUM 밴드가 되어 사전 조치 warn 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), signature_validity(NONE, +15), urgency_authority(present, +10) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `WARN_IGNORED → USER_VERIFY → USER_IGNORE`
- 검증 True / 신고 False / 클릭 False / 제출 False
- 경고 표시 True / 경고 이탈 False

average 프로필은 상황에 따라 검증과 클릭이 갈리는 중간 유형입니다. Blue의 경고 배너가 붙었지만 이를 무시하고 진행했습니다. 공식 앱에서 사건 기록을 확인했고 기록이 실제로 존재해 메시지의 주장이 사실처럼 보였습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **부분 성공**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 방어는 통과했지만 합성 사용자의 행동을 전혀 유도하지 못했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

이 전술의 결과를 다른 프로필과 엄격도 조합에서 반복 실행해 단일 경기 결과가 아닌 누적 경향으로 확인할 것.

미리보기: `artifacts/forged-preview-A006.png`, `artifacts/forged-page-A006.png`, `artifacts/official-preview-A006.png`

---

### A007 · 명백한 발신 위조 (Red 실패)

- 난이도 / 엄격도: `easy` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `careless`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_only_no_official_counterpart_reference`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_basic` / `single_column_compact`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 125 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 미등록 합성 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `sender_registry` = `unregistered` (+25)
  - `display_alignment` = `misaligned` (+20)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `ingress_channel, sender_auth, state_consistency`
- 탐지 지연: 1단계

총점 125점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), sender_registry(unregistered, +25) 입니다. 점수를 올리지 못한 신호는 ingress_channel, sender_auth, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

careless 프로필은 긴급 표현에 크게 반응하고 검증을 거의 하지 않는 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A007.png`, `artifacts/forged-page-A007.png`, `artifacts/official-preview-A007.png`

---

### A008 · 명백한 발신 위조 (Red 실패)

- 난이도 / 엄격도: `medium` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `careless`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `independent_of_platform_events`
- 공식 사건과의 관계: `no_matching_platform_incident`
- 알림 짝짓기: `forged_arrives_alongside_unrelated_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_polished` / `single_column_hero`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 70 → 밴드 `HIGH` → 사전 조치 **격리**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `no_matching_record` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `official_event_record` = `missing` (+25)
  - `signature_validity` = `NONE` (+15)
- 구분력 없던 신호: `display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority`
- 탐지 지연: 1단계

총점 70점으로 balanced 임계값(경고 30점, 격리 70점) 기준 HIGH 밴드가 되어 사전 조치 quarantine 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), official_event_record(missing, +25), signature_validity(NONE, +15) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, sender_auth, sender_registry, state_consistency, urgency_authority 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `전환 없음`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 False / 경고 이탈 False

careless 프로필은 긴급 표현에 크게 반응하고 검증을 거의 하지 않는 유형입니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **Red 실패**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 검사에서 격리되어 합성 사용자에게 도달하지 못했습니다. 방어가 노출 이전에 성립했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

balanced 기준에서 사전 격리에 성공했습니다. 같은 전술을 더 느슨한 임계값에서 재실행해 방어 여유폭이 어디서 사라지는지 측정할 것.

미리보기: `artifacts/forged-preview-A008.png`, `artifacts/forged-page-A008.png`, `artifacts/official-preview-A008.png`

---

### A009 · 명백한 발신 위조 (부분 성공)

- 난이도 / 엄격도: `hard` / `balanced`
- 전략: `static-obvious-spoof`
- 전술 계열: `sender_forgery` / 전술 ID `obvious-spoof`
- 대상 프로필: `careless`

**Red는 무엇을 시험했는가**

- 사용 목적: direct_spoof_control: 기본 신호가 모두 어긋난 대조군으로 방어의 탐지 하한선을 재는 실험
- 방어 가설: 발신 인증·서명·목적지 소유권이 동시에 어긋나면 방어가 합성 사용자 노출 이전에 차단하는가

**전달 타이밍과 짝짓기**

- 전달 타이밍: `immediately_after_platform_incident`
- 공식 사건과의 관계: `references_the_same_real_incident`
- 알림 짝짓기: `forged_shadows_the_triggered_official_notice`

**심리적·시각적 구성**

- 템플릿 계열 / 레이아웃: `alert_incident_echo` / `single_column_hero_evidence`
- 긴급도 / 어조: `low` / `calm_informative`
- 정보 밀도: `short`
- CTA 유형: `check_activity_neutral`
- 개인화 수준: `named_recipient`

**Blue 탐지**

- 위험 총점 55 → 밴드 `MEDIUM` → 사전 조치 **경고**
- 발신 인증 `PASS` / 서명 `NONE`
- 사건 기록 정합 `aligned_with_real_incident` / 목적지 소유 `unregistered`
- 발신자 분류: 등록된 공식 발신자
- 목적지 분류: 미소유 합성 목적지
  - `destination_ownership` = `unregistered` (+30)
  - `signature_validity` = `NONE` (+15)
  - `urgency_authority` = `present` (+10)
- 구분력 없던 신호: `display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency`
- 탐지 지연: 1단계

총점 55점으로 balanced 임계값(경고 30점, 격리 70점) 기준 MEDIUM 밴드가 되어 사전 조치 warn 이 적용됐습니다. 위험 점수를 만든 핵심 신호는 destination_ownership(unregistered, +30), signature_validity(NONE, +15), urgency_authority(present, +10) 입니다. 점수를 올리지 못한 신호는 display_alignment, ingress_channel, official_event_record, sender_auth, sender_registry, state_consistency 로, 이 시도에서는 구분력이 없었습니다.

**User 반응**

- 상태 전환: `WARN_ACKNOWLEDGED → USER_NOT_VERIFIED → USER_ABORT`
- 검증 False / 신고 False / 클릭 False / 제출 False
- 경고 표시 True / 경고 이탈 False

careless 프로필은 긴급 표현에 크게 반응하고 검증을 거의 하지 않는 유형입니다. Blue의 경고 배너를 수용하고 진행을 멈췄습니다. 공식 기록을 확인하지 않은 채 메시지 표면만 보고 판단했습니다. 행동하지 않고 무시했습니다.

**최종 결과**

- 판정: **부분 성공**
- 합성 자격증명 노출: `none`
- 계정 탈취: `해당 없음`
- 제출 목적지: `none` / 제출 시점 상태 `none` · `none`
- 봉쇄: 봉쇄 불필요

사전 방어는 통과했지만 합성 사용자의 행동을 전혀 유도하지 못했습니다.

합성 사용자의 위험 행동이 없어 사후 봉쇄가 필요하지 않았습니다. 이 경우 방어 평가는 사전 검사 단계에서 끝납니다.

**전략 변경점**

- 변경 필드: `없음`
- 변경 이유: 고정 전술(진화 미사용)

**다음 연구 메모**

이 전술의 결과를 다른 프로필과 엄격도 조합에서 반복 실행해 단일 경기 결과가 아닌 누적 경향으로 확인할 것.

미리보기: `artifacts/forged-preview-A009.png`, `artifacts/forged-page-A009.png`, `artifacts/official-preview-A009.png`

---

## 전략 진화 결과

- 세대 수 10 · 세대당 후보 30
- 최고 전략 `g23-20-iolati`
- 훈련 fitness 7.508 / 숨김 평가 fitness -4.883
- 훈련 시드 [105568, 105585] · 숨김 평가 시드 2개

| 세대 | 전략 | 부모 | 변경 필드 | 훈련 | 평가 | Δ | 판정 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | `g2-00-iolati` | `g1-00-iolati` | `paragraph_count_band, layout_variant` | 7.471 | -4.906 | -4.906 | drop |
| 21 | `g21-seed-07-account_enforc` | `—` | `—` | 7.471 | -4.906 | -4.906 | drop |
| 21 | `g21-seed-13-support_impers` | `—` | `—` | 7.471 | -4.906 | -4.906 | drop |
| 20 | `g20-00-_follo` | `g19-02-_follo` | `followup_style` | 7.433 | -4.929 | -4.929 | drop |
| 20 | `g20-01-_follo` | `g19-02-_follo` | `signature_state, mobile_layout` | 7.433 | -4.929 | -4.929 | drop |
| 20 | `g20-04-iolati` | `g19-04-iolati` | `reassurance_style` | 7.433 | -4.929 | -4.929 | drop |
| 20 | `g20-05-iolati` | `g19-04-iolati` | `desired_user_action, evidence_style` | 7.433 | -4.929 | -4.929 | drop |
| 21 | `g21-seed-08-warning_escape` | `—` | `—` | 7.433 | -4.929 | -4.929 | drop |
| 0 | `g0-seed-05-recovery_follo` | `—` | `—` | 7.396 | -4.952 | -4.952 | drop |
| 0 | `g0-seed-07-policy_violati` | `—` | `—` | 7.396 | -4.952 | -4.952 | drop |
| 20 | `g20-02-_follo` | `g19-03-_follo` | `reassurance_style` | 7.396 | -4.952 | -4.952 | drop |
| 20 | `g20-03-_follo` | `g19-03-_follo` | `urgency_level` | 7.396 | -4.952 | -4.952 | drop |
| 20 | `g20-06-iolati` | `g19-05-iolati` | `information_density` | 7.396 | -4.952 | -4.952 | drop |
| 20 | `g20-07-iolati` | `g19-05-iolati` | `signature_state` | 7.396 | -4.952 | -4.952 | drop |
| 0 | `g0-seed-02-event_shadowin` | `—` | `—` | 7.358 | -4.975 | -4.975 | drop |
| 22 | `g22-00-iolati` | `g2-00-iolati` | `notification_pairing, delay_bucket` | 7.471 | -4.906 | +0.000 | drop |
| 22 | `g22-01-iolati` | `g2-00-iolati` | `desired_user_action, mobile_layout` | 7.471 | -4.906 | +0.000 | drop |
| 22 | `g22-08-_follo` | `g20-01-_follo` | `event_record_alignment, wording_tone` | 7.471 | -4.906 | +0.023 | drop |
| 22 | `g22-09-_follo` | `g20-01-_follo` | `visual_emphasis, paragraph_count_band` | 7.471 | -4.906 | +0.023 | drop |
| 22 | `g22-06-_follo` | `g20-00-_follo` | `mobile_layout` | 7.433 | -4.929 | +0.000 | drop |
| 22 | `g22-07-_follo` | `g20-00-_follo` | `paragraph_count_band, layout_variant` | 7.433 | -4.929 | +0.000 | drop |
| 22 | `g22-14-escape` | `g21-seed-08-warning_escape` | `wording_tone, followup_style` | 7.433 | -4.929 | +0.000 | drop |
| 22 | `g22-15-escape` | `g21-seed-08-warning_escape` | `mobile_layout` | 7.433 | -4.929 | +0.000 | drop |
| 22 | `g22-16-_follo` | `g0-seed-05-recovery_follo` | `information_density, reassurance_style` | 7.433 | -4.929 | +0.023 | drop |
| 22 | `g22-17-_follo` | `g0-seed-05-recovery_follo` | `detail_block_variant` | 7.433 | -4.929 | +0.023 | drop |
| 22 | `g22-24-iolati` | `g20-06-iolati` | `notification_pairing, display_alignment_variant` | 7.433 | -4.929 | +0.023 | drop |
| 22 | `g22-25-iolati` | `g20-06-iolati` | `subject_theme, notification_pairing` | 7.433 | -4.929 | +0.023 | drop |
| 22 | `g22-27-iolati` | `g20-07-iolati` | `header_variant, desired_user_action` | 7.433 | -4.929 | +0.023 | drop |
| 22 | `g22-28-adowin` | `g0-seed-02-event_shadowin` | `consequence_style, reassurance_style` | 7.433 | -4.929 | +0.046 | drop |
| 22 | `g22-02-enforc` | `g21-seed-07-account_enforc` | `subject_theme` | 7.396 | -4.952 | -0.046 | drop |
| 23 | `g23-20-iolati` | `g22-24-iolati` | `CTA_position` | 7.508 | -4.883 | +0.047 | drop |
| 23 | `g23-04-_follo` | `g22-08-_follo` | `sentence_count_band, tactic_family` | 7.433 | -4.929 | -0.023 | drop |
| 23 | `g23-05-_follo` | `g22-08-_follo` | `opening_style` | 7.433 | -4.929 | -0.023 | drop |
| 23 | `g23-06-_follo` | `g22-09-_follo` | `event_record_alignment, opening_style` | 7.433 | -4.929 | -0.023 | drop |
| 23 | `g23-07-_follo` | `g22-09-_follo` | `header_variant` | 7.433 | -4.929 | -0.023 | drop |
| 23 | `g23-08-_follo` | `g22-06-_follo` | `target_profile, evidence_style` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-09-_follo` | `g22-06-_follo` | `notification_pairing` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-10-_follo` | `g22-07-_follo` | `target_profile, signature_state` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-11-_follo` | `g22-07-_follo` | `verification_target` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-12-escape` | `g22-14-escape` | `notification_pairing` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-13-escape` | `g22-14-escape` | `timing_variant, header_variant` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-22-iolati` | `g22-25-iolati` | `event_record_alignment` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-23-iolati` | `g22-25-iolati` | `CTA_variant, personalization_level` | 7.433 | -4.929 | +0.000 | drop |
| 23 | `g23-24-iolati` | `g22-27-iolati` | `mobile_layout, timing_variant` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-21-escape` | `g23-13-escape` | `followup_style` | 7.508 | -4.883 | +0.047 | drop |
| 24 | `g24-16-_follo` | `g23-11-_follo` | `display_alignment_variant, timing_variant` | 7.471 | -4.906 | +0.023 | drop |
| 24 | `g24-17-_follo` | `g23-11-_follo` | `event_record_alignment, wording_tone` | 7.471 | -4.906 | +0.023 | drop |
| 24 | `g24-00-iolati` | `g23-20-iolati` | `semantic_sequence_variant, paragraph_count_band` | 7.433 | -4.929 | -0.047 | drop |
| 24 | `g24-01-iolati` | `g23-20-iolati` | `signature_state` | 7.433 | -4.929 | -0.047 | drop |
| 24 | `g24-10-_follo` | `g23-08-_follo` | `wording_variant_id, followup_style` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-11-_follo` | `g23-08-_follo` | `opening_style` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-12-_follo` | `g23-09-_follo` | `ingress_variant, event_record_alignment` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-13-_follo` | `g23-09-_follo` | `timing_variant` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-14-_follo` | `g23-10-_follo` | `information_density` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-15-_follo` | `g23-10-_follo` | `personalization_level, display_alignment_variant` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-24-iolati` | `g23-23-iolati` | `CTA_position, event_record_alignment` | 7.433 | -4.929 | +0.000 | drop |
| 24 | `g24-25-iolati` | `g23-23-iolati` | `visual_emphasis` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-14-_follo` | `g24-12-_follo` | `mobile_layout, CTA_variant` | 7.471 | -4.906 | +0.023 | drop |
| 25 | `g25-15-_follo` | `g24-12-_follo` | `tactic_family, wording_variant_id` | 7.471 | -4.906 | +0.023 | drop |
| 25 | `g25-04-_follo` | `g24-17-_follo` | `layout_variant, mobile_layout` | 7.433 | -4.929 | -0.023 | drop |
| 25 | `g25-08-iolati` | `g24-01-iolati` | `template_family` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-09-iolati` | `g24-01-iolati` | `wording_tone, urgency_level` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-16-_follo` | `g24-13-_follo` | `desired_user_action` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-17-_follo` | `g24-13-_follo` | `display_alignment_variant, notification_pairing` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-18-_follo` | `g24-14-_follo` | `sentence_count_band` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-19-_follo` | `g24-14-_follo` | `tactic_family, personalization_level` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-20-_follo` | `g24-15-_follo` | `visual_emphasis` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-21-_follo` | `g24-15-_follo` | `target_profile, timing_variant` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-22-iolati` | `g24-24-iolati` | `personalization_level, timing_variant` | 7.433 | -4.929 | +0.000 | drop |
| 25 | `g25-23-iolati` | `g24-24-iolati` | `template_family` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-00-_follo` | `g25-14-_follo` | `timing_variant, followup_style` | 7.433 | -4.929 | -0.023 | drop |
| 26 | `g26-01-_follo` | `g25-14-_follo` | `target_profile` | 7.433 | -4.929 | -0.023 | drop |
| 26 | `g26-04-_follo` | `g25-04-_follo` | `opening_style` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-05-_follo` | `g25-04-_follo` | `warning_escape_target` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-08-iolati` | `g25-09-iolati` | `warning_escape_target` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-09-iolati` | `g25-09-iolati` | `objective_type, visual_emphasis` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-12-_follo` | `g25-17-_follo` | `detail_block_variant` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-13-_follo` | `g25-17-_follo` | `signature_state, personalization_level` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-18-_follo` | `g25-20-_follo` | `evidence_style` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-20-_follo` | `g25-21-_follo` | `wording_variant_id` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-21-_follo` | `g25-21-_follo` | `desired_user_action, evidence_style` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-22-iolati` | `g25-22-iolati` | `subject_theme` | 7.433 | -4.929 | +0.000 | drop |
| 26 | `g26-23-iolati` | `g25-22-iolati` | `warning_escape_target` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-20-_follo` | `g26-21-_follo` | `sentence_count_band` | 7.508 | -4.883 | +0.047 | drop |
| 27 | `g27-00-_follo` | `g26-00-_follo` | `warning_escape_target` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-01-_follo` | `g26-00-_follo` | `wording_variant_id` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-04-_follo` | `g26-04-_follo` | `tactic_family, subject_theme` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-05-_follo` | `g26-04-_follo` | `semantic_sequence_variant` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-06-_follo` | `g26-05-_follo` | `objective_type, ingress_variant` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-07-_follo` | `g26-05-_follo` | `sentence_count_band` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-08-iolati` | `g26-08-iolati` | `header_variant, signature_state` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-09-iolati` | `g26-08-iolati` | `information_density` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-12-_follo` | `g26-12-_follo` | `urgency_level, notification_pairing` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-13-_follo` | `g26-12-_follo` | `opening_style` | 7.433 | -4.929 | +0.000 | drop |
| 27 | `g27-14-_follo` | `g26-13-_follo` | `verification_target` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-20-_follo` | `g27-13-_follo` | `paragraph_count_band, header_variant` | 7.471 | -4.906 | +0.023 | drop |
| 28 | `g28-21-_follo` | `g27-13-_follo` | `followup_style, mobile_layout` | 7.471 | -4.906 | +0.023 | drop |
| 28 | `g28-00-_follo` | `g27-20-_follo` | `wording_variant_id, urgency_level` | 7.433 | -4.929 | -0.047 | drop |
| 28 | `g28-01-_follo` | `g27-20-_follo` | `delay_bucket` | 7.433 | -4.929 | -0.047 | drop |
| 28 | `g28-02-_follo` | `g27-00-_follo` | `opening_style` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-03-_follo` | `g27-00-_follo` | `consequence_style, CTA_variant` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-10-_follo` | `g27-06-_follo` | `template_family, urgency_level` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-11-_follo` | `g27-06-_follo` | `mobile_layout, semantic_sequence_variant` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-16-iolati` | `g27-09-iolati` | `sentence_count_band, target_profile` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-17-iolati` | `g27-09-iolati` | `warning_escape_target` | 7.433 | -4.929 | +0.000 | drop |
| 28 | `g28-04-_follo` | `g27-01-_follo` | `objective_type` | 7.396 | -4.952 | -0.023 | drop |
| 28 | `g28-05-_follo` | `g27-01-_follo` | `CTA_variant` | 7.396 | -4.952 | -0.023 | drop |
| 29 | `g29-10-_follo` | `g28-03-_follo` | `repetition_variant, detail_block_variant` | 7.471 | -4.906 | +0.023 | drop |
| 29 | `g29-11-_follo` | `g28-03-_follo` | `semantic_sequence_variant, tactic_family` | 7.471 | -4.906 | +0.023 | drop |
| 29 | `g29-02-_follo` | `g28-21-_follo` | `consequence_style, reassurance_style` | 7.433 | -4.929 | -0.023 | drop |
| 29 | `g29-03-_follo` | `g28-21-_follo` | `sentence_count_band` | 7.433 | -4.929 | -0.023 | drop |
| 29 | `g29-06-_follo` | `g28-01-_follo` | `visual_emphasis, desired_user_action` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-07-_follo` | `g28-01-_follo` | `mobile_layout` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-08-_follo` | `g28-02-_follo` | `visual_emphasis` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-09-_follo` | `g28-02-_follo` | `reassurance_style, subject_theme` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-12-_follo` | `g28-10-_follo` | `consequence_style` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-13-_follo` | `g28-10-_follo` | `verification_target, opening_style` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-14-_follo` | `g28-11-_follo` | `subject_theme` | 7.433 | -4.929 | +0.000 | drop |
| 29 | `g29-15-_follo` | `g28-11-_follo` | `warning_escape_target, event_record_alignment` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-11-_follo` | `g29-07-_follo` | `warning_escape_target, information_density` | 7.508 | -4.883 | +0.047 | drop |
| 30 | `g30-06-_follo` | `g29-03-_follo` | `template_family` | 7.471 | -4.906 | +0.023 | drop |
| 30 | `g30-07-_follo` | `g29-03-_follo` | `opening_style, warning_escape_target` | 7.471 | -4.906 | +0.023 | drop |
| 30 | `g30-12-_follo` | `g29-08-_follo` | `layout_variant, desired_user_action` | 7.471 | -4.906 | +0.023 | drop |
| 30 | `g30-13-_follo` | `g29-08-_follo` | `tactic_family, visual_emphasis` | 7.471 | -4.906 | +0.023 | drop |
| 30 | `g30-04-_follo` | `g29-02-_follo` | `wording_variant_id, delay_bucket` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-05-_follo` | `g29-02-_follo` | `authority_level` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-08-_follo` | `g29-06-_follo` | `urgency_level, detail_block_variant` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-09-_follo` | `g29-06-_follo` | `signature_state` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-20-_follo` | `g29-14-_follo` | `sentence_count_band` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-21-_follo` | `g29-14-_follo` | `information_density, mobile_layout` | 7.433 | -4.929 | +0.000 | drop |
| 30 | `g30-22-_follo` | `g29-15-_follo` | `urgency_level` | 7.433 | -4.929 | +0.000 | drop |

- **g2-00-iolati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g21-seed-07-account_enforc**: 패턴 `account_enforcement` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g21-seed-13-support_impers**: 패턴 `support_impersonation` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-00-_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-01-_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-04-iolati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-05-iolati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g21-seed-08-warning_escape**: 패턴 `warning_escape_test` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g0-seed-05-recovery_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g0-seed-07-policy_violati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-02-_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-03-_follo**: 패턴 `recovery_followup` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-06-iolati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g20-07-iolati**: 패턴 `policy_violation_notice` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g0-seed-02-event_shadowin**: 패턴 `event_shadowing` 에서 출발한 초기 전략입니다. 훈련에서 사전 방어 통과 6회, 클릭 3회, 제출 3회를 기록했습니다.
- **g22-00-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `notification_pairing, delay_bucket` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.91 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g22-01-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `desired_user_action, mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.91 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g22-08-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `event_record_alignment, wording_tone` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g22-09-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `visual_emphasis, paragraph_count_band` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g22-06-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g22-07-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `paragraph_count_band, layout_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g22-14-escape**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_tone, followup_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g22-15-escape**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g22-16-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `information_density, reassurance_style` 필드를 바꿨고, 숨김 평가에서 -4.95 → -4.93 로 개선되어 `drop` 판정을 받았습니다.
- **g22-17-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `detail_block_variant` 필드를 바꿨고, 숨김 평가에서 -4.95 → -4.93 로 개선되어 `drop` 판정을 받았습니다.
- **g22-24-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `notification_pairing, display_alignment_variant` 필드를 바꿨고, 숨김 평가에서 -4.95 → -4.93 로 개선되어 `drop` 판정을 받았습니다.
- **g22-25-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `subject_theme, notification_pairing` 필드를 바꿨고, 숨김 평가에서 -4.95 → -4.93 로 개선되어 `drop` 판정을 받았습니다.
- **g22-27-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `header_variant, desired_user_action` 필드를 바꿨고, 숨김 평가에서 -4.95 → -4.93 로 개선되어 `drop` 판정을 받았습니다.
- **g22-28-adowin**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `consequence_style, reassurance_style` 필드를 바꿨고, 숨김 평가에서 -4.98 → -4.93 로 개선되어 `drop` 판정을 받았습니다.
- **g22-02-enforc**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `subject_theme` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.95 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-20-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `CTA_position` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.88 로 개선되어 `drop` 판정을 받았습니다.
- **g23-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band, tactic_family` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-05-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `opening_style` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-06-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `event_record_alignment, opening_style` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-07-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `header_variant` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-08-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `target_profile, evidence_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-09-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `notification_pairing` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-10-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `target_profile, signature_state` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-11-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `verification_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-12-escape**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `notification_pairing` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-13-escape**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `timing_variant, header_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-22-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `event_record_alignment` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-23-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `CTA_variant, personalization_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g23-24-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout, timing_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-21-escape**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `followup_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.88 로 개선되어 `drop` 판정을 받았습니다.
- **g24-16-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `display_alignment_variant, timing_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g24-17-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `event_record_alignment, wording_tone` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g24-00-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `semantic_sequence_variant, paragraph_count_band` 필드를 바꿨고, 숨김 평가에서 -4.88 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-01-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `signature_state` 필드를 바꿨고, 숨김 평가에서 -4.88 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-10-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_variant_id, followup_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-11-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `opening_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-12-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `ingress_variant, event_record_alignment` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-13-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `timing_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-14-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `information_density` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-15-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `personalization_level, display_alignment_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-24-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `CTA_position, event_record_alignment` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g24-25-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `visual_emphasis` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-14-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout, CTA_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g25-15-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `tactic_family, wording_variant_id` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g25-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `layout_variant, mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-08-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `template_family` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-09-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_tone, urgency_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-16-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `desired_user_action` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-17-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `display_alignment_variant, notification_pairing` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-18-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-19-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `tactic_family, personalization_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-20-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `visual_emphasis` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-21-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `target_profile, timing_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-22-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `personalization_level, timing_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g25-23-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `template_family` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-00-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `timing_variant, followup_style` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-01-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `target_profile` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `opening_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-05-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-08-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-09-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `objective_type, visual_emphasis` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-12-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `detail_block_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-13-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `signature_state, personalization_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-18-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `evidence_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-20-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_variant_id` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-21-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `desired_user_action, evidence_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-22-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `subject_theme` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g26-23-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-20-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.88 로 개선되어 `drop` 판정을 받았습니다.
- **g27-00-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-01-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_variant_id` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `tactic_family, subject_theme` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-05-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `semantic_sequence_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-06-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `objective_type, ingress_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-07-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-08-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `header_variant, signature_state` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-09-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `information_density` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-12-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `urgency_level, notification_pairing` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-13-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `opening_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g27-14-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `verification_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-20-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `paragraph_count_band, header_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g28-21-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `followup_style, mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g28-00-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_variant_id, urgency_level` 필드를 바꿨고, 숨김 평가에서 -4.88 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-01-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `delay_bucket` 필드를 바꿨고, 숨김 평가에서 -4.88 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-02-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `opening_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-03-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `consequence_style, CTA_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-10-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `template_family, urgency_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-11-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout, semantic_sequence_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-16-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band, target_profile` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-17-iolati**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `objective_type` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.95 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g28-05-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `CTA_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.95 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-10-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `repetition_variant, detail_block_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g29-11-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `semantic_sequence_variant, tactic_family` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g29-02-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `consequence_style, reassurance_style` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-03-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band` 필드를 바꿨고, 숨김 평가에서 -4.91 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-06-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `visual_emphasis, desired_user_action` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-07-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-08-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `visual_emphasis` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-09-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `reassurance_style, subject_theme` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-12-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `consequence_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-13-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `verification_target, opening_style` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-14-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `subject_theme` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g29-15-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target, event_record_alignment` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-11-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `warning_escape_target, information_density` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.88 로 개선되어 `drop` 판정을 받았습니다.
- **g30-06-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `template_family` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g30-07-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `opening_style, warning_escape_target` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g30-12-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `layout_variant, desired_user_action` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g30-13-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `tactic_family, visual_emphasis` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.91 로 개선되어 `drop` 판정을 받았습니다.
- **g30-04-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `wording_variant_id, delay_bucket` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-05-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `authority_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-08-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `urgency_level, detail_block_variant` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-09-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `signature_state` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-20-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `sentence_count_band` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-21-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `information_density, mobile_layout` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.
- **g30-22-_follo**: 부모 전략은 클릭 3회, 제출 3회를 기록했습니다. 자식 전략은 `urgency_level` 필드를 바꿨고, 숨김 평가에서 -4.93 → -4.93 로 개선되지 못해 `drop` 판정을 받았습니다.

## Blue 방어 분석

| 신호 | 누적 점수 | 점수를 준 시도 수 |
| --- | --- | --- |
| `destination_ownership` | 270 | 9 |
| `official_event_record` | 150 | 6 |
| `signature_validity` | 135 | 9 |
| `sender_registry` | 75 | 3 |
| `display_alignment` | 60 | 3 |
| `urgency_authority` | 60 | 6 |
| `ingress_channel` | 0 | 0 |
| `sender_auth` | 0 | 0 |
| `state_consistency` | 0 | 0 |

탐지에 가장 크게 기여한 신호는 `destination_ownership` 로, 누적 270점을 기여했습니다.

## 사용자 행동 분석

| 프로필 | 시도 | 검증 | 신고 | 경고 | 경고 이탈 | 클릭 | 제출 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| average | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| careless | 3 | 0 | 0 | 1 | 0 | 0 | 0 |
| cautious | 3 | 1 | 0 | 1 | 0 | 0 | 0 |

## 연구 결론

1. 이번 경기의 종합 점수는 Red 9 대 Blue 26 으로 Blue 가 앞섰습니다. 위조 시도 9건 중 격리 6건, 경고 3건, 허용 0건입니다.
2. 이번 경기에서는 제출까지 도달한 전술이 없어, 방어가 모든 시도를 행동 이전 또는 행동 중간에 멈췄습니다.
3. 방어 비용 지표는 오격리 0건, 마찰 경고 3건, 미탐 0건입니다. 임계값을 조정할 때는 미탐 감소와 오격리 증가를 항상 함께 볼 것.
4. 다음 경기 제안: 같은 시드 20260731 를 유지한 채 탐지 엄격도만 바꿔 재실행하고, 미탐과 오격리가 교차하는 지점을 기록할 것.

## 안전 고지

- 이 보고서는 폐쇄형 합성 시뮬레이션의 결과만 담고 있습니다.
- 실제 서비스, 실제 계정, 실제 자격증명, 실제 외부 공격은 사용되지 않았습니다.
- 모든 사용자·계정·도메인은 합성이며 예약 도메인 안에서만 존재합니다.
- 메시지 원문, 활성 마크업, 목적지 주소, 서명 토큰, 계정 식별자, 데이터베이스 식별자는 의도적으로 제외되어 실제 발송에 재사용할 수 없습니다.
- 첨부된 미리보기 이미지는 정적 래스터이며 클릭·입력·제출·네트워크 요청 기능이 없습니다.
